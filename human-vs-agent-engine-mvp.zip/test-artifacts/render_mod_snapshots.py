from __future__ import annotations

import html
import json
import subprocess
from pathlib import Path

import httpx
from weasyprint import HTML

API = "http://127.0.0.1:8000"
OUT = Path("/workspace/scratch")
FONT = Path("/tmp/hva-font/node_modules/@fontsource/noto-sans-sc")


def esc(value: object) -> str:
    return html.escape(str(value))


def api(method: str, path: str, payload: dict | None = None) -> dict | list:
    with httpx.Client(trust_env=False, timeout=10) as client:
        response = client.request(method, API + path, json=payload)
    response.raise_for_status()
    return response.json()


def metric_rows(evaluation: dict) -> str:
    labels = {
        "player_engagement": "ENGAGEMENT",
        "engine_generality": "GENERALITY",
        "dynamism": "DYNAMISM",
        "virtual_player_rating": "VIRTUAL PLAYER",
        "ai_opponent_intelligence": "AI INTELLIGENCE",
    }
    rows = []
    for key, value in evaluation["dimensions"].items():
        if value is None:
            continue
        rows.append(
            f'<div class="metric"><span>{labels[key]}</span><i><b style="width:{value * 100}%"></b></i><strong>{value:.3f}</strong></div>'
        )
    return "".join(rows)


def tactical_visual(match: dict) -> str:
    units = match["state"]["units"]
    names = {player["id"]: player["name"] for player in match["players"]}
    by_pos = {(unit["x"], unit["y"]): (pid, unit) for pid, unit in units.items()}
    cells = []
    for y in range(5):
        for x in range(5):
            if (x, y) in by_pos:
                pid, unit = by_pos[(x, y)]
                agent = pid.startswith("agent")
                cells.append(
                    f'<div class="cell unit {"enemy" if agent else "human"}"><em>{"AI" if agent else "H"}</em><small>{esc(names[pid])}<br>HP {unit["hp"]} · EN {unit["energy"]}</small></div>'
                )
            else:
                cells.append('<div class="cell"></div>')
    return '<div class="board">' + "".join(cells) + "</div>"


def racing_visual(match: dict) -> str:
    state = match["state"]
    names = {player["id"]: player["name"] for player in match["players"]}
    rows = []
    for pid, car in state["cars"].items():
        width = min(100, car["position"] / state["track_length"] * 100)
        rows.append(
            f'<div class="trackrow"><div><b>{esc(names[pid])}</b><span>P{car["position"]} · V{car["speed"]} · F{car["fuel"]} · T{car["tyres"]}</span></div><i><b style="width:{width}%"></b></i></div>'
        )
    return f'<div class="weather">WEATHER <b>{state["weather"].upper()}</b> · TRACK {state["track_length"]}</div>' + "".join(rows)


def debate_visual(match: dict) -> str:
    state = match["state"]
    names = {player["id"]: player["name"] for player in match["players"]}
    rows = ['<div class="topic">“Should AI participate in public decision-making?”</div>']
    for pid, support in state["support"].items():
        rows.append(
            f'<div class="debater"><div><b>{esc(names[pid])}</b><span>CRED {state["credibility"][pid]:.1f} · LAST {state["last_move"][pid]}</span></div><i><b style="width:{support}%"></b></i><strong>{support:.1f}%</strong></div>'
        )
    return "".join(rows)


def crisis_visual(match: dict) -> str:
    state = match["state"]
    stats = [("THREAT", state["threat"], 110), ("SUPPLIES", state["supplies"], 100), ("INTEL", state["intel"], 100), ("TRUST", state["trust"], 100)]
    gauges = []
    for label, value, maximum in stats:
        gauges.append(
            f'<div class="gauge"><span>{label}</span><strong>{value:.1f}</strong><i><b style="width:{min(100, value / maximum * 100)}%"></b></i></div>'
        )
    agents = []
    for pid, summary in match["agent_summaries"].items():
        agents.append(
            f'<div class="brain"><b>{esc(pid[:14])}</b><span>DECISIONS {summary["decisions"]} · MEMORY {summary["memory_depth"]}</span><small>GOAL {esc(summary["world_model"].get("objective"))} · SHARED FACTS {summary["world_model"].get("shared_fact_count")}</small></div>'
        )
    return '<div class="gauges">' + "".join(gauges) + '</div><div class="brains">' + "".join(agents) + "</div>"


def events(match: dict) -> str:
    items = []
    for event in match["events"][-7:]:
        payload = event["payload"]
        detail = payload.get("action_type") or payload.get("move") or payload.get("strategy") or ""
        items.append(f'<div><b>#{event["seq"]}</b><span>{esc(event["type"])}</span><small>{esc(detail)}</small></div>')
    return "".join(items)


def render_match(match: dict, evaluation: dict, filename: str, subtitle: str) -> None:
    visuals = {
        "tactical_duel": tactical_visual,
        "racing_strategy": racing_visual,
        "debate_arena": debate_visual,
        "crisis_coop": crisis_visual,
    }
    action_buttons = "".join(
        f'<span class="action">{esc(action["type"])} {esc(" ".join(map(str, action["payload"].values())))}</span>'
        for action in match["legal_actions"]
    ) or '<span class="action muted">对局已结束</span>'
    score_rows = "".join(
        f'<span>{esc(next(player["name"] for player in match["players"] if player["id"] == pid))}<b>{value:.3f}</b></span>'
        for pid, value in match["scores"].items()
    )
    document = shell(
        f"""
        <div class="top"><div><p>LIVE API MOD TEST · MVP-2</p><h1>Human <em>VS</em> Agent</h1><small>{esc(subtitle)}</small></div><div class="run"><span>{esc(match['mod_id'])}</span><b>{esc(match['mode'])}</b><small>{match['id'][:12]}</small></div></div>
        <div class="layout">
          <aside><h2>TEST CONSOLE</h2><label>MATCH STATUS</label><div class="status"><b>{match['status'].upper()}</b><span>TURN {match['state'].get('turn', 0)}</span></div><label>LEGAL ACTIONS</label><div class="actions">{action_buttons}</div><label>FIVE-DIMENSION EVAL</label>{metric_rows(evaluation)}<div class="composite"><span>COMPOSITE</span><b>{evaluation['composite_score']:.3f}</b><small>{evaluation['version']}</small></div></aside>
          <main><div class="panel game"><div class="panelhead"><h2>GAME STATE</h2><span>RULES VALID {str(evaluation['valid_for_comparison']).upper()}</span></div>{visuals[match['mod_id']](match)}<div class="scores">{score_rows}</div></div><div class="panel timeline"><div class="panelhead"><h2>LIVE EVENT STREAM</h2><span>LAST 7 EVENTS</span></div><div class="eventlist">{events(match)}</div></div></main>
        </div>
        """
    )
    html_path = Path("/tmp") / f"{filename}.html"
    pdf_path = Path("/tmp") / f"{filename}.pdf"
    html_path.write_text(document, encoding="utf-8")
    HTML(filename=str(html_path), base_url=str(FONT)).write_pdf(pdf_path)
    subprocess.run(["pdftocairo", "-png", "-singlefile", "-r", "96", str(pdf_path), str(OUT / filename)], check=True)


def shell(content: str) -> str:
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>
@page{{size:1280px 780px;margin:0}}*{{box-sizing:border-box}}body{{margin:0;background:#090b10;color:#eef4ff;font-family:'DejaVu Sans',Arial,sans-serif;font-size:14px;padding:34px 42px;background-image:radial-gradient(circle at 82% 0,#1a2a48 0,transparent 38%)}}.top{{height:100px;display:flex;justify-content:space-between;border-bottom:1px solid #27324a;padding-bottom:18px}}p{{margin:0;color:#58e6d9;letter-spacing:.18em;font-size:11px}}h1{{font-size:38px;margin:4px 0 0}}h1 em{{color:#ff5c7a;font-style:normal}}.top small{{color:#8da0bd}}.run{{text-align:right;padding-top:4px}}.run span,.run b,.run small{{display:block}}.run span{{color:#58e6d9}}.run b{{font-size:17px;margin:5px 0}}.layout{{display:grid;grid-template-columns:350px 1fr;gap:16px;margin-top:16px;height:590px}}aside,.panel{{background:#111622e8;border:1px solid #27324a;padding:18px}}aside h2,.panel h2{{margin:0;font-size:18px}}label{{display:block;color:#8da0bd;font-size:11px;letter-spacing:.12em;margin:16px 0 6px}}.status{{display:flex;justify-content:space-between;background:#0c111b;border:1px solid #27324a;padding:10px}}.status b{{color:#58e6d9}}.actions{{display:flex;gap:6px;flex-wrap:wrap}}.action{{background:#151d2c;border:1px solid #33415e;padding:5px 8px;color:#dbe8fb;font-size:11px}}.muted{{color:#8da0bd}}.metric{{display:grid;grid-template-columns:115px 1fr 38px;gap:8px;align-items:center;margin:7px 0;font-size:10px}}.metric i,.trackrow i,.debater i,.gauge i{{height:7px;background:#202a3d;display:block}}.metric i b,.trackrow i b,.debater i b,.gauge i b{{height:100%;display:block;background:linear-gradient(90deg,#ff5c7a,#58e6d9)}}.metric strong{{font-size:11px}}.composite{{margin-top:15px;border-top:1px solid #27324a;padding-top:12px;display:grid;grid-template-columns:1fr auto;align-items:center}}.composite b{{font-size:27px;color:#58e6d9}}.composite small{{grid-column:1/3;color:#8da0bd}}main{{display:grid;grid-template-rows:380px 194px;gap:16px}}.panelhead{{display:flex;justify-content:space-between;border-bottom:1px solid #27324a;padding-bottom:9px;margin-bottom:13px}}.panelhead span{{font-size:10px;color:#58e6d9;letter-spacing:.1em}}.board{{display:grid;grid-template-columns:repeat(5,58px);grid-template-rows:repeat(5,45px);gap:4px;justify-content:center}}.cell{{background:#0c111b;border:1px solid #27324a}}.unit{{padding:5px;display:flex;align-items:center;gap:6px}}.unit em{{font-style:normal;font-weight:bold;font-size:15px}}.unit small{{font-size:8px}}.human{{border-color:#58e6d9;color:#58e6d9}}.enemy{{border-color:#ff5c7a;color:#ff5c7a}}.scores{{display:flex;gap:8px;margin-top:12px}}.scores span{{flex:1;background:#0c111b;padding:7px 10px;display:flex;justify-content:space-between}}.scores b{{color:#58e6d9}}.eventlist{{display:grid;grid-template-columns:repeat(7,1fr);gap:5px}}.eventlist div{{background:#0c111b;border-top:2px solid #33415e;padding:7px 6px;min-height:78px}}.eventlist b,.eventlist span,.eventlist small{{display:block}}.eventlist b{{color:#58e6d9;font-size:10px}}.eventlist span{{font-size:9px;margin:5px 0;word-break:break-all}}.eventlist small{{color:#8da0bd;font-size:8px}}.weather,.topic{{background:#0c111b;padding:11px;margin-bottom:14px;color:#bcd0ed}}.trackrow,.debater{{margin:15px 0}}.trackrow>div,.debater>div{{display:flex;justify-content:space-between;margin-bottom:5px}}.trackrow span,.debater span{{color:#8da0bd;font-size:10px}}.debater{{display:grid;grid-template-columns:190px 1fr 45px;gap:9px;align-items:center}}.debater>div{{display:block;margin:0}}.debater span{{display:block}}.gauges{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}.gauge{{background:#0c111b;padding:10px;display:grid;grid-template-columns:1fr auto;gap:5px}}.gauge i{{grid-column:1/3}}.brains{{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}}.brain{{border:1px solid #33415e;padding:9px}}.brain b,.brain span,.brain small{{display:block}}.brain b{{color:#58e6d9}}.brain span{{margin:4px 0}}.brain small{{color:#8da0bd;font-size:9px}}
</style></head><body>{content}</body></html>"""


def main() -> None:
    mods = api("GET", "/api/mods")
    titles = {
        "tactical_duel": "Tactical Duel",
        "racing_strategy": "Racing Strategy",
        "debate_arena": "Debate Arena",
        "crisis_coop": "Crisis Co-op",
    }
    descriptions = {
        "tactical_duel": "Move, charge and attack on a 5×5 battlefield.",
        "racing_strategy": "Manage speed, fuel and tyres through changing weather.",
        "debate_arena": "Compete for virtual audience support with strategic arguments.",
        "crisis_coop": "Share facts and resources to stabilize a cascading crisis.",
    }
    catalog = shell(
        '<div class="top"><div><p>LIVE API MOD TEST · MVP-2</p><h1>Human <em>VS</em> Agent</h1><small>Local debug console · MOD catalog loaded</small></div><div class="run"><span>ENGINE ONLINE</span><b>4 MODS READY</b><small>GET /api/mods · HTTP 200</small></div></div>'
        + '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:28px">'
        + "".join(f'<div class="panel" style="height:210px"><p>{esc(mod["id"])}</p><h2 style="font-size:25px;margin:12px 0">{titles[mod["id"]]}</h2><div style="color:#8da0bd;height:52px">{descriptions[mod["id"]]}</div><div class="actions">{"".join(f"<span class=\"action\">{esc(tag)}</span>" for tag in mod["tags"] or mod["capabilities"][:3])}</div><label>SUPPORTED MODES</label><small>{esc(" · ".join(mod["supported_modes"]))}</small></div>' for mod in mods)
        + "</div>"
    )
    catalog_html = Path("/tmp/mod-test-catalog.html")
    catalog_html.write_text(catalog, encoding="utf-8")
    catalog_pdf = Path("/tmp/mod-test-catalog.pdf")
    HTML(filename=str(catalog_html), base_url=str(FONT)).write_pdf(catalog_pdf)
    subprocess.run(["pdftocairo", "-png", "-singlefile", "-r", "96", str(catalog_pdf), str(OUT / "mod-test-01-catalog")], check=True)

    tactical = api("POST", "/api/matches", {"mod_id": "tactical_duel", "mode": "human_vs_agent", "human_name": "Tester", "seed": 7})
    for _ in range(3):
        action = tactical["legal_actions"][0]
        tactical = api("POST", f'/api/matches/{tactical["id"]}/actions', {"actor_id": tactical["human_player_id"], "action": action})
    render_match(tactical, api("GET", f'/api/matches/{tactical["id"]}/evaluation'), "mod-test-02-tactical", "Tactical Duel · Human actions + automatic Agent turns · In progress")

    racing = api("POST", "/api/matches", {"mod_id": "racing_strategy", "mode": "agent_vs_agent", "seed": 9})
    render_match(racing, api("GET", f'/api/matches/{racing["id"]}/evaluation'), "mod-test-03-racing", "Racing Strategy · Agent vs Agent · Final state")

    debate = api("POST", "/api/matches", {"mod_id": "debate_arena", "mode": "agent_vs_agent", "seed": 12})
    render_match(debate, api("GET", f'/api/matches/{debate["id"]}/evaluation'), "mod-test-04-debate", "Debate Arena · World model and memory decisions · Final state")

    crisis = api("POST", "/api/matches", {"mod_id": "crisis_coop", "mode": "agent_coop", "seed": 2})
    render_match(crisis, api("GET", f'/api/matches/{crisis["id"]}/evaluation'), "mod-test-05-crisis", "Crisis Co-op · Two Agents sharing a fact blackboard · Final state")

    (OUT / "mod-test-run.json").write_text(json.dumps({"tactical": tactical, "racing": racing, "debate": debate, "crisis": crisis}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
